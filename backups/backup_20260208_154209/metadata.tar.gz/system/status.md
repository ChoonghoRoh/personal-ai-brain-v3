# 시스템 상태

**생성 시간**: 2026-01-07 05:46:21

## 📊 통계

### Qdrant 벡터 데이터베이스
- 상태: error
- 오류: 'CollectionInfo' object has no attribute 'vectors_count'

### 파일 통계
- 총 Markdown 파일: 4개
- 총 크기: 0.0 MB
- 프로젝트 파일: 4개
- 참고 자료: 0개
- 임시 파일: 0개
- 아카이브: 0개
- 시스템 파일: 0개

## 🔄 최근 변경사항

- 변경사항 없음

## 🛠️ 시스템 구성

- 벡터 DB: Qdrant (localhost:6333)
- 컬렉션: brain_documents
- 임베딩 모델: sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2

## 📝 다음 작업

자동화된 시스템이 정상 작동 중입니다.
